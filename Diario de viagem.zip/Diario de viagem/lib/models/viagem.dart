class Viagem {
  final String id;
  final String destino;
  final DateTime dataInicio;
  final DateTime dataFim;
  final String notas;
  final String foto;

  Viagem({
    required this.id,
    required this.destino,
    required this.dataInicio,
    required this.dataFim,
    required this.notas,
    required this.foto,
  });

  // Método para converter um JSON para um objeto Viagem
  factory Viagem.fromJson(Map<String, dynamic> json) {
    return Viagem(
      id: json['id'],
      destino: json['destino'],
      dataInicio: DateTime.parse(json['dataInicio']),
      dataFim: DateTime.parse(json['dataFim']),
      notas: json['notas'],
      foto: json['foto'],
    );
  }

  // Método para converter um objeto Viagem para um JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'destino': destino,
      'dataInicio': dataInicio.toIso8601String(),
      'dataFim': dataFim.toIso8601String(),
      'notas': notas,
      'foto': foto,
    };
  }
}
