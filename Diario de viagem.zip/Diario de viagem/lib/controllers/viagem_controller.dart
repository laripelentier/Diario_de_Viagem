import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:diario_de_viagem/models/viagem.dart';

class ViagemController {
  final String baseUrl =
      'https://diario-de-viagem-f79fe-default-rtdb.firebaseio.com/viagens';

  Future<List<Viagem>> getViagens() async {
    final response = await http.get(Uri.parse('$baseUrl.json'));

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      final List<Viagem> viagens = [];

      data.forEach((id, viagemData) {
        viagens.add(Viagem.fromJson({
          'id': id,
          ...viagemData,
        }));
      });

      return viagens;
    } else {
      throw Exception('Erro ao carregar viagens');
    }
  }

  Future<void> addViagem(Viagem viagem) async {
    final response = await http.post(
      Uri.parse('$baseUrl.json'),
      body: json.encode(viagem.toJson()),
    );

    if (response.statusCode != 200) {
      throw Exception('Erro ao adicionar viagem');
    }
  }

  Future<void> updateViagem(Viagem viagem) async {
    final response = await http.put(
      Uri.parse('$baseUrl/${viagem.id}.json'),
      body: json.encode(viagem.toJson()),
    );

    if (response.statusCode != 200) {
      throw Exception('Erro ao atualizar viagem');
    }
  }
}
