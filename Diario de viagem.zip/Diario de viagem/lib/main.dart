import 'package:flutter/material.dart';
import 'package:diario_de_viagem/controllers/viagem_controller.dart';
import 'package:diario_de_viagem/models/viagem.dart';

void main() {
  runApp(const DiarioDeViagem());
}

class DiarioDeViagem extends StatelessWidget {
  const DiarioDeViagem({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Diário de Viagem',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const DiarioDeViagemPage(),
    );
  }
}

class DiarioDeViagemPage extends StatefulWidget {
  const DiarioDeViagemPage({super.key});

  @override
  State<DiarioDeViagemPage> createState() => _DiarioDeViagemPageState();
}

class _DiarioDeViagemPageState extends State<DiarioDeViagemPage> {
  final ViagemController viagemController = ViagemController();
  late Future<List<Viagem>> _listaViagens;

  @override
  void initState() {
    super.initState();
    _listaViagens = viagemController.getViagens();
  }

  void _refreshList() {
    setState(() {
      _listaViagens = viagemController.getViagens();
    });
  }

  void _showForm([Viagem? viagem]) {
    final formKey = GlobalKey<FormState>();
    String destino = viagem?.destino ?? '';
    DateTime dataInicio = viagem?.dataInicio ?? DateTime.now();
    DateTime dataFim =
        viagem?.dataFim ?? DateTime.now().add(const Duration(days: 1));
    String notas = viagem?.notas ?? '';
    String foto = viagem?.foto ?? '';

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(viagem == null ? 'Adicionar Viagem' : 'Editar Viagem'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    initialValue: destino,
                    decoration: const InputDecoration(labelText: 'Destino'),
                    onSaved: (value) => destino = value!,
                  ),
                  TextFormField(
                    initialValue: dataInicio.toString(),
                    decoration:
                        const InputDecoration(labelText: 'Data de Início'),
                    onSaved: (value) => dataInicio = DateTime.parse(value!),
                  ),
                  TextFormField(
                    initialValue: dataFim.toString(),
                    decoration: const InputDecoration(labelText: 'Data de Fim'),
                    onSaved: (value) => dataFim = DateTime.parse(value!),
                  ),
                  TextFormField(
                    initialValue: notas,
                    decoration: const InputDecoration(labelText: 'Notas'),
                    onSaved: (value) => notas = value!,
                  ),
                  TextFormField(
                    initialValue: foto,
                    decoration: const InputDecoration(labelText: 'Foto (URL)'),
                    onSaved: (value) => foto = value!,
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                if (formKey.currentState!.validate()) {
                  formKey.currentState!.save();
                  final novaViagem = Viagem(
                    id: viagem?.id ??
                        DateTime.now()
                            .toString(), // Gerar um ID único se for uma nova viagem
                    destino: destino,
                    dataInicio: dataInicio,
                    dataFim: dataFim,
                    notas: notas,
                    foto: foto,
                  );
                  if (viagem == null) {
                    viagemController
                        .addViagem(novaViagem)
                        .then((_) => _refreshList());
                  } else {
                    viagemController
                        .updateViagem(novaViagem)
                        .then((_) => _refreshList());
                  }
                  Navigator.of(context).pop();
                }
              },
              child: const Text('Salvar'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Diário de Viagem'),
      ),
      body: FutureBuilder<List<Viagem>>(
        future: _listaViagens,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text('Erro: ${snapshot.error}'),
            );
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text('Sem viagens!'),
            );
          }

          final viagens = snapshot.data!;
          return ListView.builder(
            itemCount: viagens.length,
            itemBuilder: (context, index) {
              final viagem = viagens[index];
              return ListTile(
                title: Text(viagem.destino),
                subtitle: Text(
                    'De: ${viagem.dataInicio.toLocal()} Até: ${viagem.dataFim.toLocal()}'),
                onTap: () => _showForm(viagem),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
